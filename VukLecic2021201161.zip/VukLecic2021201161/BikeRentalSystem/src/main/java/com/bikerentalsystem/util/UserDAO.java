package com.bikerentalsystem.util;

import com.bikerentalsystem.models.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDAO {
    private static final Logger logger = Logger.getLogger(UserDAO.class.getName());
    private Connection connection;

    public UserDAO() {
        try {
            connection = DatabaseConnection.getConnection();
            logger.info("Database connection established successfully.");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to get database connection", e);
        }
    }

    //Metode
    public void addUser(User user) {
        String query = "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getRole());
            int rowsAffected = preparedStatement.executeUpdate();
            logger.info("User added. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to add user", e);
        }
    }

    public boolean validateUser(String email, String password) {
        String query = "SELECT * FROM users WHERE email = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();
            boolean isValidUser = resultSet.next();
            logger.info("User validation: " + (isValidUser ? "success" : "failure"));
            return isValidUser;
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to validate user", e);
            return false;
        }
    }

    public User getUserById(int id) {
        String query = "SELECT * FROM users WHERE id = ?";
        User user = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setId(resultSet.getInt("id"));
                user.setName(resultSet.getString("name"));
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
                logger.info("User retrieved: " + user);
            } else {
                logger.warning("No user found with ID: " + id);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to retrieve user by ID", e);
        }

        return user;
    }

    public User getUserByEmail(String email) {
        String query = "SELECT * FROM users WHERE email = ?";
        User user = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setId(resultSet.getInt("id"));
                user.setName(resultSet.getString("name"));
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
                logger.info("User retrieved by email: " + user);
            } else {
                logger.warning("No user found with email: " + email);
            }

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to retrieve user by email", e);
        }

        return user;
    }

    public void updateUser(User user) {
        String query = "UPDATE users SET name = ?, email = ?, password = ?, role = ? WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getEmail());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getRole());
            preparedStatement.setInt(5, user.getId());
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                logger.info("User updated. Rows affected: " + rowsAffected);
            } else {
                logger.warning("No user was updated. User ID: " + user.getId());
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to update user", e);
        }
    }

    public void deleteUser(int id) {
        String query = "DELETE FROM users WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            logger.info("User deleted. Rows affected: " + rowsAffected);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to delete user", e);
        }
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setName(resultSet.getString("name"));
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
                user.setRole(resultSet.getString("role"));
                users.add(user);
            }
            logger.info("All users retrieved successfully");

        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to retrieve all users", e);
        }

        return users;
    }
}