package com.bikerentalsystem.util;

import com.bikerentalsystem.models.Bike;
import com.bikerentalsystem.models.Rental;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RentalDAO {
    private Connection connection;

    public RentalDAO() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Rental mapResultSetToRental(ResultSet resultSet) throws SQLException {
        Rental rental = new Rental();
        rental.setId(resultSet.getInt("id"));
        rental.setUserId(resultSet.getInt("user_id"));
        rental.setBicycleId(resultSet.getInt("bicycle_id"));
        rental.setRentalStart(resultSet.getDate("rental_start"));
        rental.setRentalEnd(resultSet.getDate("rental_end"));

        Bike bike = new Bike();
        bike.setId(resultSet.getInt("bicycle_id"));
        bike.setModel(resultSet.getString("model"));
        bike.setType(resultSet.getString("type"));
        bike.setAvailability(resultSet.getInt("availability"));
        bike.setPricePerHour(resultSet.getDouble("price_per_hour"));

        rental.setBike(bike);
        return rental;
    }

    public List<Rental> getAllRentals() {
        List<Rental> rentalList = new ArrayList<>();
        String query = "SELECT r.id, r.user_id, r.bicycle_id, r.rental_start, r.rental_end, b.model, b.type, b.availability, b.price_per_hour " +
                       "FROM rentals r " +
                       "JOIN bicycles b ON r.bicycle_id = b.id";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                Rental rental = mapResultSetToRental(resultSet);
                rentalList.add(rental);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rentalList;
    }

    public List<Rental> getRentalsByUserId(int userId) {
        List<Rental> rentalList = new ArrayList<>();
        String query = "SELECT r.id, r.user_id, r.bicycle_id, r.rental_start, r.rental_end, b.model, b.type, b.availability, b.price_per_hour " +
                       "FROM rentals r " +
                       "JOIN bicycles b ON r.bicycle_id = b.id " +
                       "WHERE r.user_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Rental rental = mapResultSetToRental(resultSet);
                rentalList.add(rental);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rentalList;
    }

    public Rental getRentalById(int id) {
        String query = "SELECT r.id, r.user_id, r.bicycle_id, r.rental_start, r.rental_end, b.model, b.type, b.availability, b.price_per_hour " +
                       "FROM rentals r " +
                       "JOIN bicycles b ON r.bicycle_id = b.id " +
                       "WHERE r.id = ?";
        Rental rental = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                rental = mapResultSetToRental(resultSet);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rental;
    }

    public void addRental(Rental rental) {
        String query = "INSERT INTO rentals (user_id, bicycle_id, rental_start, rental_end) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, rental.getUserId());
            preparedStatement.setInt(2, rental.getBicycleId());
            preparedStatement.setDate(3, new java.sql.Date(rental.getRentalStart().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(rental.getRentalEnd().getTime()));
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateRental(Rental rental) {
        String query = "UPDATE rentals SET user_id = ?, bicycle_id = ?, rental_start = ?, rental_end = ? WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, rental.getUserId());
            preparedStatement.setInt(2, rental.getBicycleId());
            preparedStatement.setDate(3, new java.sql.Date(rental.getRentalStart().getTime()));
            preparedStatement.setDate(4, new java.sql.Date(rental.getRentalEnd().getTime()));
            preparedStatement.setInt(5, rental.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRental(int id) {
        String query = "DELETE FROM rentals WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}